// This file is intentionally blank.
// If you were implementing ICinemachineComponent interface, please refactor to 
// inherit from CinemachineComponentBase instead.
