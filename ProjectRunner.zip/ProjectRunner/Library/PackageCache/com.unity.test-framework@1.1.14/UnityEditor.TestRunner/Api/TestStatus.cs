namespace UnityEditor.TestTools.TestRunner.Api
{
    public enum TestStatus
    {
        Inconclusive,
        Skipped,
        Passed,
        Failed
    }
}
